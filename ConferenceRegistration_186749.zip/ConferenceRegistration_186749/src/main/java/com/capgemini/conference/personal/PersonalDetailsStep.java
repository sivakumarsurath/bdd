package com.capgemini.conference.personal;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.capgemini.conference.bean.PersonalDetails;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalDetailsStep {

	private WebDriver driver;
	private PersonalDetails personalDetails;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:/BDD_749/ConferenceRegistration_186749/drivers/chromedriver.exe");

		driver = new ChromeDriver();
	}

	@Given("^user is on 'PersonalDetails' page$")
	public void user_is_on_PersonalDetails_page() throws Throwable {
		driver.get("C:/BDD_749/ConferenceRegistration_186749/webpages/ConferenceRegistartion.html");
		personalDetails = new PersonalDetails();
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		personalDetails.setFirstName("");
		personalDetails.InitialiseElements(driver);
	}

	@Then("^displays 'Please fill the first Name'$")
	public void displays_Please_fill_the_first_Name() throws Throwable {
		String expectedMessage = "Please fill the First Name";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		// driver.close();
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
		personalDetails.setFirstName("siva");
		personalDetails.setLastName("");
		personalDetails.InitialiseElements(driver);

	}

	@Then("^displays 'Please fill the Last Name'$")
	public void displays_Please_fill_the_Last_Name() throws Throwable {
		String expectedMessage = "Please fill the Last Name";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		// driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		personalDetails.setFirstName("siva");
		personalDetails.setLastName("kumar");
		personalDetails.setEmail("");
		personalDetails.InitialiseElements(driver);
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		String expectedMessage = "Please fill the Email";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		// driver.close();
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		personalDetails.setFirstName("siva");
		personalDetails.setLastName("kumar");
		personalDetails.setEmail("kumar@gmail.com");
		personalDetails.setPhoneNumber("");
		personalDetails.InitialiseElements(driver);
	}

	@Then("^display 'Please fill Mobile Number'$")
	public void display_Please_fill_Mobile_Number() throws Throwable {
		String expectedMessage = "Please fill the Mobile No.";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		// driver.close();
	}

	@When("^user enters invalid Number of People attending$")
	public void user_enters_invalid_Number_of_People_attending() throws Throwable {

	}

	@Then("^display 'Number of people attending'$")
	public void display_Number_of_people_attending() throws Throwable {

	}

	@When("^user does not enter BuildingName$")
	public void user_does_not_enter_BuildingName() throws Throwable {

	}

	@Then("^display 'Please Enter BuildingName'$")
	public void display_Please_Enter_BuildingName() throws Throwable {

	}

	@When("^user enters invalid Area$")
	public void user_enters_invalid_Area() throws Throwable {

	}

	@Then("^display 'Please fill Area'$")
	public void display_Please_fill_Area() throws Throwable {

	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
		personalDetails.setFirstName("siva");
		personalDetails.setLastName("kumar");
		personalDetails.setEmail("kumar@gmail.com");
		personalDetails.setPhoneNumber("8745784545");
		personalDetails.clickCity("");
		personalDetails.InitialiseElements(driver);

	}

	@Then("^display 'Please fill City'$")
	public void display_Please_fill_City() throws Throwable {
		String expectedMessage = "Please select city";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		// driver.close();
	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
		personalDetails.setFirstName("siva");
		personalDetails.setLastName("kumar");
		personalDetails.setEmail("kumar@gmail.com");
		personalDetails.setPhoneNumber("8745784545");
		personalDetails.clickCity("Bangalore");
		personalDetails.clickState("select state");
		personalDetails.InitialiseElements(driver);

	}

	@Then("^display 'Please fill the State'$")
	public void display_Please_fill_the_State() throws Throwable {
		String expectedMessage = "Please select state";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		// driver.close();
	}

	@When("^user enters invalid Access$")
	public void user_enters_invalid_Access() throws Throwable {

	}

	@Then("^display 'Please fill the Access'$")
	public void display_Please_fill_the_Access() throws Throwable {

	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		personalDetails.setFirstName("siva");
		personalDetails.setLastName("kumar");
		personalDetails.setEmail("kumar@gmail.com");
		personalDetails.setPhoneNumber("8745784545");
		personalDetails.clickCity("Bangalore");
		personalDetails.clickState("Karnataka");
		personalDetails.clickMemberStatus(2);

		personalDetails.InitialiseElements(driver);
	}

	@Then("^A page with Payment Details is Opened$")
	public void a_page_with_Payment_Details_is_Opened() throws Throwable {

		driver.get("C:/BDD_749/ConferenceRegistration_186749/webpages/PaymentDetails.html");
		driver.close();
	}
}
