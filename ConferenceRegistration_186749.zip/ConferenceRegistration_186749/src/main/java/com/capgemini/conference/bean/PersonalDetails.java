package com.capgemini.conference.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PersonalDetails {
	//Initialization of web elements
	@FindBy(name = "txtFN")
	WebElement FName;

	@FindBy(name = "txtLN")
	WebElement LName;

	@FindBy(name = "Email")
	WebElement email;

	@FindBy(name = "Phone")
	WebElement phone;

	@FindBy(name = "size")
	WebElement size;

	@FindBy(name = "Address")
	WebElement Addr;

	@FindBy(name = "Address2")
	WebElement Addr2;

	@FindBy(name = "city")
	WebElement CName;

	@FindBy(name = "state")
	WebElement SName;

	@FindBy(name = "memberStatus")
	WebElement MemName;

	@FindBy(name = "memberStatus")
	WebElement MemName1;

	@FindBy(name = "btnNext")
	WebElement next;
//Getters and setters for the given web elements
	public String getFirstName() {
		return this.FName.getAttribute("value");
	}

	public void setFirstName(String txtFN) {
		this.FName.sendKeys(txtFN);
	}

	public String getLastName() {
		return this.LName.getAttribute("value");
	}

	public void setLastName(String txtLN) {
		this.LName.sendKeys(txtLN);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String Email) {
		this.email.sendKeys(Email);
	}

	public String getPhoneNumber() {
		return this.phone.getAttribute("value");
	}

	public void setPhoneNumber(String Phone) {
		this.phone.sendKeys(Phone);
	}

	public String getAddress() {
		return this.Addr.getAttribute("value");
	}

	public void setAddress(String Address) {
		this.Addr.sendKeys(Address);
	}

	public String getArea() {
		return this.Addr2.getAttribute("value");
	}

	public void setArea(String Address2) {
		this.Addr2.sendKeys(Address2);
	}

	public void clickPeople() {
		Select select = new Select(size);
		select.selectByIndex(2);
	}
//here
	public void clickCity(String string) {
		Select select = new Select(CName);
		select.selectByVisibleText("Bangalore");
	}
//here
	public void clickState(String string) {
		Select select = new Select(SName);
		select.selectByVisibleText("Karnataka");
	}

	public void clickMemberStatus(int i) {
		MemName.click();
	}

	public void clickNextButton() {
		MemName1.click();
	}

	public void InitialiseElements(WebDriver Driver) {
		PageFactory.initElements(Driver, PersonalDetails.this);
	}


}
