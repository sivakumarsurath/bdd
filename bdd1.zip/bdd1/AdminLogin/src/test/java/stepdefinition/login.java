package stepdefinition;

import cucumber.api.java.en.Given;

public class login {
	@Given("^I want to open my application$")
	public void i_want_to_open_my_application() throws Throwable {
	   
	}

	@Given("^I login with credentials \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_login_with_credentials_and(String s1, String s2) throws Throwable {
	  if(s1.equals("surath")&&s2.equals("siva123")) {
		  System.out.println("-----Welcome Siva Kumar------");
	  }
	  else {
		  System.err.println("Sorry! Try again.....");
	  }
	}



}
