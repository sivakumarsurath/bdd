package com.capgemini.conference.personal;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"},features= {"feature/PersonalDetails.feature"},glue="com.capgemini.conference.personal")
public class RunTest {

}
