package com.cg.pattern;

import java.util.Random;
import java.util.Scanner;

public class Pattern {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Character[] arr = new Character[4];
		String[] pass = new String[15];
		int i = 0;
		int m = 4;
		int l = 0, sum = 0, length = 0;
		int max = 9999;
		int min = 1000;
		System.out.println("welcome to our company");
		System.out.println("please enter the following details");
		System.out.println("enter your firstname");
		String fname = scan.next();
		System.out.println("enter the lname");
		String lname = scan.next();
		System.out.println("enter your mobile number");
		String mob = scan.next();
		System.out.println("enter Id proof");
		String proof = scan.next();
		pass[0] = Character.toString(fname.charAt(fname.length() - 1));
		pass[1] = Character.toString(lname.charAt(0));
		String p = Character.toString(mob.charAt(0)) + Character.toString(mob.charAt(2))
				+ Character.toString(mob.charAt(4)) + Character.toString(mob.charAt(6))
				+ Character.toString(mob.charAt(8));
		pass[2] = p;

		System.out.println("Enter date in the format dd/mm/yyyy");
		String date = scan.next();

		String c = Character.toString(date.charAt(0));
		String c1 = Character.toString(date.charAt(4));

		String d = c + c1;

		for (int j = 6; j < 10; j++) {
			String y = Character.toString(date.charAt(j));
			sum = sum + Integer.parseInt(y);
		}

		int z = 0;
		while (sum > 0) {
			z = sum % 10;
			l = l + z;
			sum = sum / 10;
		}
		int ll = 0;
		int zz = 0;
		int sum1 = l + Integer.parseInt(d);
		System.out.println(sum1);
		while (sum1 > 0) {
			zz = sum1 % 10;
			ll = ll + zz;
			sum1 = sum1 / 10;
		}
		String kl = Integer.toString(ll);
		System.out.println(kl);
		pass[3] = kl;

		for (int h = 0; h < proof.length(); h++) {
			if (proof.charAt(h) == 'a' || proof.charAt(h) == 'e' || proof.charAt(h) == 'i' || proof.charAt(h) == 'o'
					|| proof.charAt(h) == 'u') {

				pass[m] = Character.toString(proof.charAt(h));

				m++;
			}
		}
		proof.charAt(proof.length() - 1);
		int bp = Integer.parseInt(Character.toString(proof.charAt(proof.length() - 1)));

		if (bp % 2 == 0) {
			pass[m] = Integer.toString(bp);
		} else {
			pass[m] = Integer.toString(7);
		}

		arr[3] = fname.charAt(0);
		arr[2] = fname.charAt(1);
		arr[0] = lname.charAt(lname.length() - 1);
		arr[1] = lname.charAt(lname.length() - 2);
		Random ran = new Random();
		int n = ran.nextInt(max);
		System.out.println("you are succesfully registered" + " " + fname + lname);
		System.out.println("your login is as follows");
		System.out.print("your user name is" + " ");
		for (int k = 0; k < 4; k++) {
			System.out.print(arr[k]);
		}
		System.out.println(n);
		System.out.println("your password is:" + " ");
		for (int dl = 0; dl <= m; dl++) {
			System.out.print(pass[dl]);
		}
		System.out.println();
		System.out.println("your login credentials should be changed");
		scan.close();
	}
}
