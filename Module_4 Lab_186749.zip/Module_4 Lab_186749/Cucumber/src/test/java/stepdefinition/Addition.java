package stepdefinition;

import cucumber.api.java.en.Given;

public class Addition {
	@Given("^I want to verify that (\\d+) plus (\\d+) equals (\\d+)$")
	public void i_want_to_verify_that_plus_equals(int a, int b, int c) throws Throwable {
		if((a+b)==c){
            System.out.println("matched");
        }
        else {
            System.err.println("not matched");
        }
	}


}
