package stepdefinition;

import java.util.Random;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Product {
	@Given("^I want to open my application with the productId$")
	public void i_want_to_open_my_application_with_the_productId() throws Throwable {
	    
	}
	/*
	 * @Then("^Application was started Successfully$") public void
	 * application_was_started_Successfully() throws Throwable {
	 * System.out.println("The information you needed is Here"); }
	 */
	@Then("^The info you need is Here$")
	public void the_info_you_need_is_Here() throws Throwable {
		System.out.println("The information you needed is Here");
	}


@Then("^User enters productId equals random and sales equals (\\d+)$")
public void user_enters_productId_equals_random_and_sales_equals(int sales) throws Throwable {
	Random random = new Random();
    int ProductId= random.nextInt(100);
if(sales>30 && sales<45) {

   System.err.println("This Product with the Id "+ ProductId +" has an Poor sales....");
}
else if (sales>45 && sales<70) {
 System.out.println("This Product with the Id "+ ProductId +" has an Good sales.....");
}
else {
 System.out.println("This Product with the Id "+ ProductId +" has an Excellent sales......");
}
}
 
}


