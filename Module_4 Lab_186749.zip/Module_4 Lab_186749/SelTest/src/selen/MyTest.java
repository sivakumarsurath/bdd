
  package selen;
  
/*
 * public class MyTest { public static void main(String[] args) {
 * System.setProperty("webdriver.chrome.driver", value); webDriver driver=new
 * ChromeDriver(); driver.get("http://google.com"); webElement
 * element=driver.findElement(By.name("q")); Thread.sleep(50000);
 * element.sendKeys("java"); element.submit(); Thread.sleep(50000);
 * driver.quit(); } }
 */
 