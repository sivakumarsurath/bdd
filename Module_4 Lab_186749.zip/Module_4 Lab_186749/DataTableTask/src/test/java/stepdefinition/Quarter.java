package stepdefinition;

import java.util.List;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

    public class Quarter {
	private List<Integer> numbers;
	private int average;
	private int sum;

	@Given("^a list of quaterly customer sales$")
	public void a_list_of_quaterly_customer_sales(List<Integer> numbers) throws Throwable {
		this.numbers = numbers;
	}

	@When("^I Summarize them$")
	public void i_Summarize_them() throws Throwable {
		for (Integer number : numbers)
			sum += number;
		average = sum / 4;
	}

	@Then("^I should get (\\d+)$")
	public void i_should_get(int estVal) throws Throwable {
		assertThat(average, estVal);
		System.out.println("The average is " + average);
	}

	private void assertThat(int average2, int estVal) {

	}
}
