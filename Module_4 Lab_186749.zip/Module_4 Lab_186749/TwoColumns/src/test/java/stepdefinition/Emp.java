package stepdefinition;

import java.util.HashMap;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gherkin.formatter.model.DataTableRow;

public class Emp {
	private int ctsD;
	private int ctjD;
	private HashMap<String, Integer> eMap;
	@Given("^an organization has employees$")
	public void an_organization_has_employees(DataTable empTable) throws Throwable {
		eMap=new HashMap<String, Integer>();
		for(DataTableRow row:empTable.getGherkinRows()) {
			eMap.put(row.getCells().get(0), Integer.parseInt(row.getCells().get(1)));
		}
	}

	@When("^it Recruits (\\d+) more (.*) and (\\d+) more (.*) employees$")
	public void it_Recruits_more_P_Devpr_and_more_A_Tester_employees(int nod,String sdev, int not,String stes) throws Throwable {
		ctsD=eMap.get(sdev)+nod;
		ctjD=eMap.get(stes)+not;
	}

	@Then("^the organization will have (\\d+) P\\.Devpr and (\\d+) A\\.Tester$")
	public void the_organization_will_have_P_Devpr_and_A_Tester(int esD, int ejD) throws Throwable {
		Assert.assertThat(ctsD, CoreMatchers.is(esD));
		  Assert.assertThat(ctjD, CoreMatchers.is(ejD));
		  System.out.println(ctsD+" "+esD);
		  System.out.println(ctjD+" "+ejD);
	}

}
