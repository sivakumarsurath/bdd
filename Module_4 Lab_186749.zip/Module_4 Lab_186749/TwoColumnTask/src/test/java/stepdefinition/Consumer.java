package stepdefinition;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gherkin.formatter.model.DataTableRow;

public class Consumer {
	public int sum;
	private HashMap<String, Integer> eMap;
	@Given("^a list of prices$")
	public void a_list_of_prices(DataTable price) throws Throwable {
		eMap=new HashMap<String, Integer>();
	     for(DataTableRow row:price.getGherkinRows())
	     {
	         eMap.put(row.getCells().get(0),Integer.parseInt(row.getCells().get(1)));
	     }
	}

	@When("^I summarised them$")
	public void i_summarised_them() throws Throwable {
		 Collection<Integer> collection = eMap.values();
         Iterator<Integer> iterator = collection.iterator();
         while (iterator.hasNext()) {
             sum = sum + iterator.next();
         }
	}

	@Then("^I should get (\\d+)$")
	public void i_should_get(int sum1) throws Throwable {
		  sum1=sum;
          System.out.println("Your Total Price is:"+sum);
	}


}
