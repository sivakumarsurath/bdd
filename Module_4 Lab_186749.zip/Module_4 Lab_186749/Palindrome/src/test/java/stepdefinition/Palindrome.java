package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class Palindrome {
	public String testpal;
    public boolean ispal;
    @Given("I entered string {string}")
    public void i_entered_string(String test) throws Throwable {
       testpal=test;
    }

 

    @When("I test it for pallindrome")
    public void i_test_it_for_pallindrome() throws Throwable {
     ispal=testpal.equalsIgnoreCase(new StringBuilder(testpal).reverse().toString());
    }

 

    @Then("the result should be {string}")
    public void the_result_should_be(String s) {
      boolean estRes=Boolean.parseBoolean(s);
      if(estRes)
      {
          Assert.assertTrue(ispal);
          
      }
      else {
          Assert.assertFalse(ispal);
      }
    }
	/*String testPal;
	boolean isPal;
	@Given("I entered string {string}")
	public void i_entered_string(String test) {
		testPal=test;
	}

	@When("I test it for palindrome")
	public void i_test_it_for_palindrome() {
		isPal=testPal.equalsIgnoreCase(new StringBuilder(testPal).reverse().toString());	
	   
	}
	@Then("the result should be true")
	public void the_result_should_be_true(String s)throws Throwable {
		boolean
		  estRes=Boolean.parseBoolean(s);  
		if(estRes) 
		{ 
			Assert.assertTrue(isPal); 
			} 
		else
	
		 { 
			Assert.assertFalse(isPal); 
			}
*/
	/*
	 * @Then("the result should be true") public void
	 * the_result_should_be_true(String s)throws Throwable { boolean
	 * estRes=Boolean.parseBoolean(s); if(estRes) { Assert.assertTrue(isPal); } else
	 * { Assert.assertFalse(isPal); }
	 * 
	 * }
	 */



}
