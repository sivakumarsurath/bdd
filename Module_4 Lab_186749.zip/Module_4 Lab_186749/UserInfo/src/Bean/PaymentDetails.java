package Bean;

public class PaymentDetails {

}
