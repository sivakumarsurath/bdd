package com.capgemini.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" },features = {"Feature"},glue="com.capgemini.stepdefinition")
public class RunTester {

}
