package stepdefinition;

import cucumber.api.java.en.Given;

public class Intrest {


@Given("^I want to verify that (\\d+) multiplies (\\d+) multiplies (\\d+) divided by (\\d+) equals to (\\d+)$")
public void i_want_to_verify_that_multiplies_multiplies_divided_by_equals_to(int P, int T, int R, int a, int b) throws Throwable {
    if(((P*T*R)/100)==b) {
    	System.out.println("good");
    }
    else{
    	System.err.println("bad");
    }
}

}
